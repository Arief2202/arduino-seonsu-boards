#include <ESP32PWM.h>
#include <ESP32Servo.h>
#include "SeoDriveCore.h"
#include "esp32-hal-ledc.h"
#include "Arduino.h"

SeoDriveCore::SeoDriveCore(){

}

void SeoDriveCore::ServoDetach(uint8_t pin){
    int found = -1;
    for(int a=0; a<14; a++){
        if(this->attachedServoPin[a][0] == pin){
            found = a;
            return;
        }
    }
    if(found == -1) Serial.printf("Servo on Pin %d is not Attached, please attach first!\n", pin);
    else{
        servo[this->attachedServoPin[found][1]].detach();
        for(int a=found; a<13; a++){
            if(a != found){
                this->attachedServoPin[a][0] = this->attachedServoPin[a+1][0];
                this->attachedServoPin[a][1] = this->attachedServoPin[a+1][1];
            }
        }
        this->attachedServoPin[13][0] = NULL;
        this->attachedServoPin[13][1] = NULL;
    }
}

void SeoDriveCore::ServoAttach(uint8_t pin){
    servo[this->_servoNum].attach(pin);
    this->attachedServoPin[this->_servoNum][0] = pin;
    this->attachedServoPin[this->_servoNum][1] = this->_servoNum;
    this->_servoNum++;
}
void SeoDriveCore::ServoWrite(uint8_t pin, uint8_t direction){
    for(int a=0; a<14; a++){
        if(this->attachedServoPin[a][0] == pin){
            servo[this->attachedServoPin[a][1]].write(direction);
            return;
        }
    }
    Serial.printf("Servo on Pin %d is not Attached, please attach first!\n", pin);
}

void SeoDriveCore::addPWM(uint8_t pin){
    pinMode(pin, OUTPUT);
    pwm[this->pwm_index].attachPin(pin, 5000, 8);
    this->attachedPwmPin[this->pwm_index][0] = pin;
    this->attachedPwmPin[this->pwm_index][1] = pwm[this->pwm_index].getChannel();
    this->pwm_index++;
}
void SeoDriveCore::analogWrite(uint8_t pin, uint8_t pwm){
    for(int a=0; a<14; a++){
        if(this->attachedPwmPin[a][0] == pin){
            ledcWrite(attachedPwmPin[a][1], pwm);
            return;
        }
    }
    Serial.printf("PWM on Pin %d is not Added, please add first with addPWM(pin)!\n", pin);
}

void SeoDriveCore::pinMode(uint8_t pin, uint8_t mode){
    if(mode == INPUT || mode == OUTPUT || mode == INPUT_PULLUP || mode == INPUT_PULLDOWN) pinMode(pin, mode);
    else if(mode == SERVO) ServoAttach(pin);
    else if(mode == PWM) addPWM(pin);
}
void SeoDriveCore::digitalWrite(uint8_t pin, bool state){
    digitalWrite(pin, state);
}

void SeoDriveCore::begin(){
    pinMode(this->led, OUTPUT);
    pinMode(this->pwm1, OUTPUT);
    pinMode(this->pwm2, OUTPUT);
    pinMode(this->pwm3, OUTPUT);
    pinMode(this->pwm4, OUTPUT);
    pinMode(this->bts_en, OUTPUT);
    digitalWrite(this->bts_en, HIGH);
    pwm[0].attachPin(this->pwm2, 5000, 8);
    pwm[1].attachPin(this->pwm4, 5000, 8);
}

void SeoDriveCore::BTS(bool enable){
    digitalWrite(this->bts_en, enable);
}
void SeoDriveCore::MotorWrite(int left, int right){
    if(left > 0){
        digitalWrite(this->pwm1, LOW);
        ledcWrite(pwm[0].getChannel(), left);
    }
    else if(left < 0){
        digitalWrite(this->pwm1, HIGH);
        ledcWrite(pwm[0].getChannel(), 255 + left);
    }
    else{
        digitalWrite(this->pwm1, LOW);
        ledcWrite(pwm[0].getChannel(), 0);
    }
    
    if(right > 0){
        digitalWrite(this->pwm3, LOW);
        ledcWrite(pwm[1].getChannel(), right);
    }
    else if(right < 0){
        digitalWrite(this->pwm3, HIGH);
        ledcWrite(pwm[1].getChannel(), 255 + right);
    }
    else{
        digitalWrite(this->pwm3, LOW);
        ledcWrite(pwm[1].getChannel(), 0);
    }
}