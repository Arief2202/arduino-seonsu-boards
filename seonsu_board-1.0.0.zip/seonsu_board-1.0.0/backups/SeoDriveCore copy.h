#ifndef SeoDriveCore_h
#define SeoDriveCore_h

#include "ESP32PWM.h"
#include "ESP32Servo.h"
#include "Ps3Controller.h"


class SeoDriveCore {
public:
  SeoDriveCore();
  void begin();
  void ServoAttach(uint8_t pin);
  void ServoDetach(uint8_t pin);
  void BTS(bool en);
  
  void addPWM(uint8_t pin);
  void analogWrite(uint8_t pin, uint8_t pwm);
  void digitalWrite(uint8_t pin, bool state);
  void ServoWrite(uint8_t pin, uint8_t direction);
  void MotorWrite(int left, int right);
  void pinMode(uint8_t pin, uint8_t mode);

  bool BTS_ON = 1;
  bool BTS_OFF = 0;
  

  int getPwmChannel();

private:
  Servo servo[14];
  uint8_t attachedServoPin[14][2];
  uint8_t attachedPwmPin[14][2];
  ESP32PWM pwm[14];
  uint8_t led = 2;
  uint8_t pwm1 = 4;
  uint8_t pwm2 = 16;
  uint8_t pwm3 = 17;
  uint8_t pwm4 = 18;
  uint8_t bts_en = 5;
  uint8_t PWM = 10;
  uint8_t SERVO = 11;
  int _servoNum = 0;
  uint8_t pwm_index = 2;
};

#endif
