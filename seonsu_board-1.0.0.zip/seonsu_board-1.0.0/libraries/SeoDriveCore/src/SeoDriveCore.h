#ifndef SeoDriveCore_h
#define SeoDriveCore_h

#include "ESP32PWM.h"
#include "ESP32Servo.h"
#if ARDUINO >= 100
#include "Arduino.h"
#else
#include "WProgram.h"
#endif


class SeoDriveCore {
public:
  SeoDriveCore();
  void begin();
  void ServoAttach(int pin);
  void ServoDetach(int pin);
  void ServoWrite(int pin, int direction);
  void BTS(bool en);
  void debug(bool state);
  void addPWM(int pin);
  void analogWrite(int pin, int pwm);
  // void digitalWrite(int pin, bool state);
  // void pinMode(int pin, int mode);
  void pinMode(uint8_t pin, uint8_t mode);
  void digitalWrite(uint8_t pin, uint8_t val);

  bool BTS_ON = 1;
  bool BTS_OFF = 0;
  
  void MotorWrite(int left, int right);

  int getPwmChannel();

private:
  Servo servo[14];
  uint8_t attachedServoPin[14][2];
  uint8_t attachedPwmPin[14][2];
  ESP32PWM pwm[14];
  uint8_t led = 2;
  uint8_t pwm1 = 4;
  uint8_t pwm2 = 16;
  uint8_t pwm3 = 17;
  uint8_t pwm4 = 18;
  uint8_t bts_en = 5;
  int _servoNum = 0;
  uint8_t pwm_index = 2;
  uint8_t PWM = 10;
  uint8_t SERVO = 11;
  bool debugState = false;
};

#if !defined(NO_GLOBAL_INSTANCES)
extern SeoDriveCore SeoDrive;
#endif

#endif
