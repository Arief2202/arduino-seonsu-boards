#include <ESP32PWM.h>
#include <ESP32Servo.h>
#include "SeoDriveCore.h"
#include "esp32-hal-ledc.h"


SeoDriveCore::SeoDriveCore(){

} 

void SeoDriveCore::ServoDetach(int pin){
}



void SeoDriveCore::ServoAttach(int pin){
    for(int a=0; a<14; a++){
        if(this->attachedServoPin[a][0] == pin){
            if(this->debugState) Serial.printf("Pin %d is SERVO, you added this pin before!\n", pin);
            return;
        }
    }
    servo[this->_servoNum].attach(pin);
    this->attachedServoPin[this->_servoNum][0] = pin;
    this->attachedServoPin[this->_servoNum][1] = this->_servoNum;
    this->_servoNum++;
    if(this->debugState) Serial.printf("Add SERVO on Pin %d Successfully!\n", pin);
}
void SeoDriveCore::ServoWrite(int pin, int direction){
    for(int a=0; a<14; a++){
        if(this->attachedServoPin[a][0] == pin){
            servo[this->attachedServoPin[a][1]].write(direction);
            return;
        }
    }
    if(this->debugState) Serial.printf("Servo on Pin %d is not Attached, please attach first!\n", pin);
}
void SeoDriveCore::analogWrite(int pin, int pwm){
    for(int a=0; a<14; a++){
        if(this->attachedPwmPin[a][0] == pin){
            ledcWrite(attachedPwmPin[a][1], pwm);
            return;
        }
    }
    if(this->debugState) Serial.printf("PWM on Pin %d is not PWM mode, please add this pin with addPWM(pin) or pinMode(pin, PWM)!\n", pin);
}

void SeoDriveCore::addPWM(int pin){
    for(int a=0; a<14; a++){
        if(this->attachedPwmPin[a][0] == pin){
            if(this->debugState) Serial.printf("Pin %d is PWM, you added this pin before!\n", pin);
            return;
        }
    }
    pinMode(pin, OUTPUT);
    pwm[this->pwm_index].attachPin(pin, 5000, 8);
    this->attachedPwmPin[this->pwm_index][0] = pin;
    this->attachedPwmPin[this->pwm_index][1] = pwm[this->pwm_index].getChannel();
    this->pwm_index++;
    if(this->debugState) Serial.printf("Add PWM on Pin %d Successfully!\n", pin);
}

void SeoDriveCore::debug(bool state){
    this->debugState = state;
    if(this->debugState){
        Serial.begin(115200);
        Serial.println();
    }
}
void SeoDriveCore::begin(){
    if(this->debugState){
        Serial.begin(115200);
        Serial.println();
    }
    pinMode(this->led, OUTPUT);
    pinMode(this->pwm1, OUTPUT);
    pinMode(this->pwm2, OUTPUT);
    pinMode(this->pwm3, OUTPUT);
    pinMode(this->pwm4, OUTPUT);
    pinMode(this->bts_en, OUTPUT);
    digitalWrite(this->bts_en, HIGH);
    pwm[0].attachPin(this->pwm2, 5000, 8);
    pwm[1].attachPin(this->pwm4, 5000, 8);
}

void SeoDriveCore::BTS(bool enable){
    digitalWrite(this->bts_en, enable);
}
void SeoDriveCore::MotorWrite(int left, int right){
    if(left > 0){
        digitalWrite(this->pwm1, LOW);
        ledcWrite(pwm[0].getChannel(), left);
    }
    else if(left < 0){
        digitalWrite(this->pwm1, HIGH);
        ledcWrite(pwm[0].getChannel(), 255 + left);
    }
    else{
        digitalWrite(this->pwm1, LOW);
        ledcWrite(pwm[0].getChannel(), 0);
    }
    
    if(right > 0){
        digitalWrite(this->pwm3, LOW);
        ledcWrite(pwm[1].getChannel(), right);
    }
    else if(right < 0){
        digitalWrite(this->pwm3, HIGH);
        ledcWrite(pwm[1].getChannel(), 255 + right);
    }
    else{
        digitalWrite(this->pwm3, LOW);
        ledcWrite(pwm[1].getChannel(), 0);
    }
}

#include "driver/rtc_io.h"
void SeoDriveCore::pinMode(uint8_t pin, uint8_t mode)
{
    if(!digitalPinIsValid(pin)) {
        return;
    }

    if(mode == PWM) this->addPWM(pin);
    else if(mode == SERVO) this->ServoAttach(pin);
    else{ 
        uint32_t rtc_reg = rtc_gpio_desc[pin].reg;
        if(mode == ANALOG) {
            if(!rtc_reg) {
                return;//not rtc pin
            }
            //lock rtc
            uint32_t reg_val = ESP_REG(rtc_reg);
            if(reg_val & rtc_gpio_desc[pin].mux){
                return;//already in adc mode
            }
            reg_val &= ~(
                    (RTC_IO_TOUCH_PAD1_FUN_SEL_V << rtc_gpio_desc[pin].func)
                    |rtc_gpio_desc[pin].ie
                    |rtc_gpio_desc[pin].pullup
                    |rtc_gpio_desc[pin].pulldown);
            ESP_REG(RTC_GPIO_ENABLE_W1TC_REG) = (1 << (rtc_gpio_desc[pin].rtc_num + RTC_GPIO_ENABLE_W1TC_S));
            ESP_REG(rtc_reg) = reg_val | rtc_gpio_desc[pin].mux;
            //unlock rtc
            ESP_REG(DR_REG_IO_MUX_BASE + esp32_gpioMux[pin].reg) = ((uint32_t)2 << MCU_SEL_S) | ((uint32_t)2 << FUN_DRV_S) | FUN_IE;
            return;
        }

        //RTC pins PULL settings
        if(rtc_reg) {
            //lock rtc
            ESP_REG(rtc_reg) = ESP_REG(rtc_reg) & ~(rtc_gpio_desc[pin].mux);
            if(mode & PULLUP) {
                ESP_REG(rtc_reg) = (ESP_REG(rtc_reg) | rtc_gpio_desc[pin].pullup) & ~(rtc_gpio_desc[pin].pulldown);
            } else if(mode & PULLDOWN) {
                ESP_REG(rtc_reg) = (ESP_REG(rtc_reg) | rtc_gpio_desc[pin].pulldown) & ~(rtc_gpio_desc[pin].pullup);
            } else {
                ESP_REG(rtc_reg) = ESP_REG(rtc_reg) & ~(rtc_gpio_desc[pin].pullup | rtc_gpio_desc[pin].pulldown);
            }
            //unlock rtc
        }

        uint32_t pinFunction = 0, pinControl = 0;

        //lock gpio
        if(mode & INPUT) {
            if(pin < 32) {
                GPIO.enable_w1tc = ((uint32_t)1 << pin);
            } else {
                GPIO.enable1_w1tc.val = ((uint32_t)1 << (pin - 32));
            }
        } else if(mode & OUTPUT) {
            if(pin > 33){
                //unlock gpio
                return;//pins above 33 can be only inputs
            } else if(pin < 32) {
                GPIO.enable_w1ts = ((uint32_t)1 << pin);
            } else {
                GPIO.enable1_w1ts.val = ((uint32_t)1 << (pin - 32));
            }
        }

        if(mode & PULLUP) {
            pinFunction |= FUN_PU;
        } else if(mode & PULLDOWN) {
            pinFunction |= FUN_PD;
        }

        pinFunction |= ((uint32_t)2 << FUN_DRV_S);//what are the drivers?
        pinFunction |= FUN_IE;//input enable but required for output as well?

        if(mode & (INPUT | OUTPUT)) {
            pinFunction |= ((uint32_t)2 << MCU_SEL_S);
        } else if(mode == SPECIAL) {
            pinFunction |= ((uint32_t)(((pin)==1||(pin)==3)?0:1) << MCU_SEL_S);
        } else {
            pinFunction |= ((uint32_t)(mode >> 5) << MCU_SEL_S);
        }

        ESP_REG(DR_REG_IO_MUX_BASE + esp32_gpioMux[pin].reg) = pinFunction;

        if(mode & OPEN_DRAIN) {
            pinControl = (1 << GPIO_PIN0_PAD_DRIVER_S);
        }

        GPIO.pin[pin].val = pinControl;
        //unlock gpio
    }
}

void SeoDriveCore::digitalWrite(uint8_t pin, uint8_t val)
{
    if(val) {
        if(pin < 32) {
            GPIO.out_w1ts = ((uint32_t)1 << pin);
        } else if(pin < 34) {
            GPIO.out1_w1ts.val = ((uint32_t)1 << (pin - 32));
        }
    } else {
        if(pin < 32) {
            GPIO.out_w1tc = ((uint32_t)1 << pin);
        } else if(pin < 34) {
            GPIO.out1_w1tc.val = ((uint32_t)1 << (pin - 32));
        }
    }
}
